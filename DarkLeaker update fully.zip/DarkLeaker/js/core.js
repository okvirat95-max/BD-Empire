const SUPABASE_URL = "https://mgtbeiqqehvnrudlebio.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_5I5otxiF4C5rA195oSxNqA_jft4qlZf";
const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

let currentUserProfile = null;
let networkSystemConfiguration = null;

// Secure Browser-Persisted Session Anti-Spam Tracking Engine
const TransmissionRateLimiter = {
    checkThrottled(actionIdentifier, millisecondsLimit = 2500) {
        const timeNow = Date.now();
        const key = `darkleaker_rate_${actionIdentifier}`;
        const lastTimestamp = localStorage.getItem(key);
        
        if (lastTimestamp && (timeNow - parseInt(lastTimestamp, 10) < millisecondsLimit)) {
            return true;
        }
        localStorage.setItem(key, timeNow.toString());
        return false;
    }
};

// Global-Safe XSS Sanitizer accessible immediately on inline evaluation
window.escapeStringXSS = function(rawStr) {
    if (!rawStr) return '';
    return rawStr.replace(/[&<>'"]/g, match => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
    }[match] || match));
};

async function executeGlobalMainframeInitialization() {
    try {
        const { data: configuration } = await supabaseClient.from('system_settings').select('*').eq('id', 1).single();
        networkSystemConfiguration = configuration;

        if (networkSystemConfiguration) {
            if (networkSystemConfiguration.global_announcement) {
                renderSystemTicker(networkSystemConfiguration.global_announcement);
            }
            if (networkSystemConfiguration.maintenance_mode && !window.location.pathname.includes('admin')) {
                document.body.innerHTML = `
                    <div style="background:#050202; color:#ff003c; height:100vh; display:flex; flex-direction:column; justify-content:center; align-items:center; font-family:monospace; text-align:center;">
                        <h1>[ALERT] TERMINAL DOWN FOR MAINTENANCE</h1>
                        <p style="color:#8a7373; margin-top:1rem;">Structural upgrades underway. Re-routing systems core modules.</p>
                    </div>`;
                return;
            }
        }

        const { data: { session } } = await supabaseClient.auth.getSession();
        if (session) {
            const { data: profile } = await supabaseClient.from('profiles').select('*').eq('id', session.user.id).single();
            if (profile?.is_banned) {
                alert("Security Access Violation: Your token has been blocklisted by administration.");
                await supabaseClient.auth.signOut();
                window.location.href = 'index.html';
                return;
            }
            currentUserProfile = profile;
            applyAuthedNavigationNodeUI();
        } else {
            applyGuestNavigationNodeUI();
        }
    } catch (err) {
        console.error("Mainframe Core Handshake Exception: ", err);
    }
}

function renderSystemTicker(msg) {
    const block = document.createElement('div');
    block.className = 'global-ticker-broadcast';
    block.innerText = `[BROADCAST SIGNAL] :: ${msg}`;
    document.body.insertBefore(block, document.body.firstChild);
}

function applyAuthedNavigationNodeUI() {
    const node = document.getElementById('navbar-interactive-auth-zone');
    if (!node) return;
    node.innerHTML = `
        <div style="display:flex; align-items:center; gap:1rem;">
            <a href="dashboard.html" style="text-decoration:none; display:flex; align-items:center; gap:0.5rem;">
                <span style="color:#fff; font-size:0.8rem; font-family:var(--font-cyber);">${window.escapeStringXSS(currentUserProfile.username)}</span>
                ${currentUserProfile.is_premium ? '<span class="premium-verified-badge">PREMIUM</span>' : ''}
            </a>
            ${['admin', 'owner'].includes(currentUserProfile.role) ? '<a href="admin.html" class="btn-action" style="border-color:orange; color:orange; padding:0.3rem 0.8rem;">Command Base</a>' : ''}
            <button onclick="executePlatformSignout()" class="btn-action" style="padding:0.3rem 0.8rem;">Disconnect</button>
        </div>
    `;
}

function applyGuestNavigationNodeUI() {
    const node = document.getElementById('navbar-interactive-auth-zone');
    if (!node) return;
    node.innerHTML = `<button onclick="executeDiscordOAuthRedirect()" class="btn-action btn-discord-sync">Connect Identity</button>`;
}

async function executeDiscordOAuthRedirect() {
    await supabaseClient.auth.signInWithOAuth({
        provider: 'discord',
        options: { redirectTo: window.location.origin + '/auth-callback.html' }
    });
}

async function executePlatformSignout() {
    await supabaseClient.auth.signOut();
    window.location.href = 'index.html';
}

document.addEventListener('DOMContentLoaded', () => {
    executeGlobalMainframeInitialization();
    
    const floatingAnchor = document.createElement('a');
    floatingAnchor.className = 'persistent-discord-anchor';
    floatingAnchor.href = "https://discord.gg/ZqWZnZm7P6";
    floatingAnchor.target = "_blank";
    floatingAnchor.innerText = "Get Support (Discord)";
    document.body.appendChild(floatingAnchor);
});
